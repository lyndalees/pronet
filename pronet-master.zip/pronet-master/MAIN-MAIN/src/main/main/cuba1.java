/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.main;
/**
 *
 * @author User
 */
public class cuba1 {
    public static void main (String[] args){
            int bilangan = 139;
            String barangan ="Biskut";
            double harga = 2.55;
            boolean status = true;
            float suhu = 4.23456892f;
            char pilihan = 'Y';
            
            System.out.println ("Stok semasa:" +bilangan +" unit");
            System.out.println ("Nama barangan:"+barangan);
            System.out.println ("Harga seunit:RM" +harga);
            System.out.println ("Status barangan:"+status);
            System.out.println ("Suhu bilik:" +suhu);
            System.out.println ("Semua maklumat adalah benar:"+pilihan);
    }
}


